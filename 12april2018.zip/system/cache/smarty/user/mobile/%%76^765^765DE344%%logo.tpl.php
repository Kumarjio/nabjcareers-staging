<?php  /* Smarty version 2.6.14, created on 2014-03-07 22:48:48
         compiled from ../field_types/display/logo.tpl */ ?>
<img src="<?php  echo $this->_tpl_vars['value']['file_url']; ?>
" border="0" alt="" />