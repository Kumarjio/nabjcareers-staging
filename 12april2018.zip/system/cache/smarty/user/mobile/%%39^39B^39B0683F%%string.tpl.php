<?php  /* Smarty version 2.6.14, created on 2017-01-26 18:55:52
         compiled from ../field_types/display/string.tpl */ ?>
<?php  echo $this->_tpl_vars['value']; ?>