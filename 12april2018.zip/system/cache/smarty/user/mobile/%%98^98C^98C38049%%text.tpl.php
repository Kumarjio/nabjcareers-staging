<?php  /* Smarty version 2.6.14, created on 2017-08-11 08:23:27
         compiled from ../field_types/display/text.tpl */ ?>
<?php  echo $this->_tpl_vars['value']; ?>