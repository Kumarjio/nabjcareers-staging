<?php  /* Smarty version 2.6.14, created on 2014-06-02 21:45:45
         compiled from ../field_types/search/string.tpl */ ?>
<input type="text" name="<?php  echo $this->_tpl_vars['id']; ?>
[equal]" class="searchString" value="<?php  echo $this->_tpl_vars['value']['equal']; ?>
" <?php  echo $this->_tpl_vars['parameters']; ?>
 />