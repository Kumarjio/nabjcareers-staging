<?php  /* Smarty version 2.6.14, created on 2015-06-26 23:41:29
         compiled from prices.tpl */ ?>
