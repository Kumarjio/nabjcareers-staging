<?php  /* Smarty version 2.6.14, created on 2018-02-12 10:07:19
         compiled from ../field_types/search/boolean.tpl */ ?>

<input type="checkbox" name="<?php  echo $this->_tpl_vars['id']; ?>
[equal]" <?php  if ($this->_tpl_vars['value']): ?>checked="checked"<?php  endif; ?> value="1" />