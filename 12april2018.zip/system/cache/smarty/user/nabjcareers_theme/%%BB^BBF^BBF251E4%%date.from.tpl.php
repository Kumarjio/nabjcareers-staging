<?php  /* Smarty version 2.6.14, created on 2018-02-08 16:18:04
         compiled from ../field_types/search/date.from.tpl */ ?>
<input type="text" name="<?php  echo $this->_tpl_vars['id']; ?>
[not_less]" value="<?php  echo $this->_tpl_vars['value']['not_less']; ?>
"  id="<?php  echo $this->_tpl_vars['id']; ?>
_notless" style="height:14px;"/>