<?php  /* Smarty version 2.6.14, created on 2018-02-25 00:38:09
         compiled from ../miscellaneous/social/summary.tpl */ ?>
