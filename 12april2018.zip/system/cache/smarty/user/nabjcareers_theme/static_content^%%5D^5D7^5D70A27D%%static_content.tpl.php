<?php  /* Smarty version 2.6.14, created on 2018-02-08 11:06:28
         compiled from static_content.tpl */ ?>
<?php  require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'eval', 'static_content.tpl', 1, false),)), $this); ?>
<?php  echo smarty_function_eval(array('var' => $this->_tpl_vars['staticContent']), $this);?>