<?php  /* Smarty version 2.6.14, created on 2018-02-08 10:50:24
         compiled from ../field_types/display/logo.tpl */ ?>
<img src="<?php  echo $this->_tpl_vars['value']['file_url']; ?>
" border="0" alt="" />