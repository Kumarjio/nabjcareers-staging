<?php  /* Smarty version 2.6.14, created on 2018-02-08 10:36:21
         compiled from empty.tpl */ ?>
<?php  echo $this->_tpl_vars['ERRORS_CONTENT'];   echo $this->_tpl_vars['MAIN_CONTENT']; ?>