<?php  /* Smarty version 2.6.14, created on 2018-02-08 16:18:04
         compiled from ../field_types/display/text.tpl */ ?>
<?php  echo $this->_tpl_vars['value']; ?>