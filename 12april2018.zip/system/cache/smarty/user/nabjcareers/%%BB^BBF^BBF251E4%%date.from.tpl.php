<?php  /* Smarty version 2.6.14, created on 2014-10-22 23:55:31
         compiled from ../field_types/search/date.from.tpl */ ?>
<input type="text" name="<?php  echo $this->_tpl_vars['id']; ?>
[not_less]" value="<?php  echo $this->_tpl_vars['value']['not_less']; ?>
"  id="<?php  echo $this->_tpl_vars['id']; ?>
_notless" style="height:14px;"/>