<?php  /* Smarty version 2.6.14, created on 2014-10-20 16:00:23
         compiled from my_listings_form.tpl */ ?>
