<?php  /* Smarty version 2.6.14, created on 2014-10-20 00:12:37
         compiled from empty.tpl */ ?>
<?php  echo $this->_tpl_vars['ERRORS_CONTENT'];   echo $this->_tpl_vars['MAIN_CONTENT']; ?>