<?php  /* Smarty version 2.6.14, created on 2014-10-22 23:55:31
         compiled from ../field_types/display/text.tpl */ ?>
<?php  echo $this->_tpl_vars['value']; ?>