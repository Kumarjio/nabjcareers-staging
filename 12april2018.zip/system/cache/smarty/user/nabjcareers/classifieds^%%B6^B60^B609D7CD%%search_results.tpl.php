<?php  /* Smarty version 2.6.14, created on 2014-10-21 15:44:03
         compiled from search_results.tpl */ ?>
