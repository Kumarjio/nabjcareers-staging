<?php  /* Smarty version 2.6.14, created on 2014-10-20 00:10:45
         compiled from ../field_types/display/string.tpl */ ?>
<?php  echo $this->_tpl_vars['value']; ?>