<?php  /* Smarty version 2.6.14, created on 2014-10-20 00:10:39
         compiled from facebook_like_button.tpl */ ?>
<div class="in_share">
	<script src="http://connect.facebook.net/en_US/all.js#xfbml=1"></script><fb:like href="<?php  echo $this->_tpl_vars['url']; ?>
" layout="button_count" show_faces="false" width="72" font="arial"></fb:like>
</div>