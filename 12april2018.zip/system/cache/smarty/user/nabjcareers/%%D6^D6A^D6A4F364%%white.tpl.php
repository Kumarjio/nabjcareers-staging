<?php  /* Smarty version 2.6.14, created on 2014-10-24 10:46:02
         compiled from white.tpl */ ?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<html>
	<head>
	    <title><?php  echo $this->_tpl_vars['GLOBALS']['settings']['site_title'];   if ($this->_tpl_vars['TITLE'] != ""): ?> :: <?php  echo $this->_tpl_vars['TITLE']; ?>
 <?php  endif; ?></title>
	</head>
	<body>
		<?php  echo $this->_tpl_vars['ERRORS_CONTENT']; ?>

		<?php  echo $this->_tpl_vars['MAIN_CONTENT']; ?>

	</body>
</html>