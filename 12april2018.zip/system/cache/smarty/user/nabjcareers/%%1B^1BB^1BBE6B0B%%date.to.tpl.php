<?php  /* Smarty version 2.6.14, created on 2014-10-22 23:55:31
         compiled from ../field_types/search/date.to.tpl */ ?>
<input type="text" name="<?php  echo $this->_tpl_vars['id']; ?>
[not_more]" value="<?php  echo $this->_tpl_vars['value']['not_more']; ?>
"  id="<?php  echo $this->_tpl_vars['id']; ?>
_notmore" style="height:14px;"/>