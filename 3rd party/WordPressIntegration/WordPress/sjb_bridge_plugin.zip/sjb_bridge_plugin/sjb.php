<?php
/*
Plugin Name: SJB
Plugin URI: http://smartjobboard.com/
Description: 
Version: 3.0
Author: SJB
Author URI: http://smartjobboard.com/
*/

define('SJB_VERSION', '3.0');
$ds = DIRECTORY_SEPARATOR;
define( 'SJB_PATH_BASE', dirname(__FILE__ )."{$ds}..{$ds}..{$ds}..{$ds}..");
add_filter('authenticate', 'sjbLogin', 40, 3);
add_action('wp_logout','sjbLogout');

function sjbLogin($user, $username, $password) {
	if ($username !== '' && $password !== '') {
		$userdata = get_userdatabylogin($username);
		$dir = getcwd();
		loadSJBToWP();
		//get the sjb user
		$SJB_errors = array();
		$logged_in = SJB_Authorization::login($username, $password, false, $SJB_errors, false);

		// user not in wordpress db, but is in sjb
		$userInfo = SJB_UserDBManager::getUserInfoByUserName($username); 
		chdir($dir);
		if ($userdata && $userInfo && !isset($SJB_errors['USER_NOT_ACTIVE']) && !isset($SJB_errors['BANNED_USER'])) {
			if (!$logged_in && !is_wp_error($user)) {
				if (SJB_UserManager::changeUserPassword($userInfo['sid'], $password)){
					$SJB_errors = array();
					$logged_in = SJB_Authorization::login($username, $password, false, $SJB_errors, false);
				}
			}
			elseif ($logged_in && is_wp_error($user)) {
				if (  in_array('incorrect_password', $user->get_error_codes()) ) {
					require_once( ABSPATH . WPINC . '/registration.php');
					loadWordPress();
					$userdata->user_pass = $password;
					$user_id = wp_update_user( get_object_vars( $userdata ));
					$user = get_userdatabylogin($username);
				}
			}
		}
		elseif ($logged_in && $userInfo && !$userdata) {
			require_once( ABSPATH . WPINC . '/registration.php');
			loadWordPress();
			$user_id = wp_create_user( $username, $password, $userInfo['email'] );
			//$user = get_userdatabylogin($username);
			$user = new WP_User($user_id);
		}
		else {
			if (isset($SJB_errors['INVALID_PASSWORD'])) {
				return new WP_Error('incorrect_password', sprintf(__('<strong>ERROR</strong>: Incorrect password. <a href="%s" title="Password Lost and Found">Lost your password</a>?'), site_url('wp-login.php?action=lostpassword', 'login')));
			}
			elseif (isset($SJB_errors['USER_NOT_ACTIVE'])){
				return new WP_Error('user_not_active', sprintf(__('<strong>ERROR</strong>: Your account is not active.', 'login')));
			}
			elseif (isset($SJB_errors['BANNED_USER'])) {
				return new WP_Error('banned_user', sprintf(__('<strong>ERROR</strong>: You IP address has been banned by site administrator.', 'login')));
			}
		}
	}
	return $user;
}

function sjbLogout(){
	$dir = getcwd();
	loadSJBToWP();
	SJB_Authorization::logout();
	chdir($dir);
}

function loadSJBToWP()
{
	// System includes
	require_once(SJB_PATH_BASE.'/system/core/System.php');
	SJB_System::loadSystemSettings (SJB_PATH_BASE.'/config.php');
	require_once(SJB_PATH_BASE.'/system/core/DB.php');
	require_once(SJB_PATH_BASE.'/system/core/WrappedFunctions.php');
	require_once(SJB_PATH_BASE.'/system/core/HelperFunctions.php');
	SJB_DB :: init(SJB_System::getSystemSettings('DBHOST'), SJB_System::getSystemSettings('DBUSER'), SJB_System::getSystemSettings('DBPASSWORD'), SJB_System::getSystemSettings('DBNAME'));
	WordPress_Session::init(SJB_System::getSystemSettings('SITE_URL'));
	chdir(SJB_PATH_BASE.'/system/lib/');
	require_once('users/User/UserDBManager.php');
	require_once("users/Authorization.php");
}

function loadWordPress() {
	global $wpdb, $table_prefix;
	$wpdb = new wpdb(DB_USER, DB_PASSWORD, DB_NAME, DB_HOST);
	$prefix = $wpdb->set_prefix($table_prefix);
}
require_once(SJB_PATH_BASE.'/system/core/Session.php');
class WordPress_Session extends SJB_Session {
	
	public static function init($url) {
		$sessionStorage = new WordPressSessionStorage();
		session_set_save_handler(
			array($sessionStorage, 'open'),
			array($sessionStorage, 'close'),
			array($sessionStorage, 'read'),
			array($sessionStorage, 'write'),
			array($sessionStorage, 'destroy'),
			array($sessionStorage, 'gc')
		);
		
		$path = SJB_Session::getSessionCookiePath($url);
		SJB_WrappedFunctions::ini_set("session.cookie_path", $path);
		SJB_WrappedFunctions::session_start();
	}
}

class WordPressSessionStorage extends SessionStorage {
	
	function write($id, $session_data) {
		$dbPath = SJB_PATH_BASE.'/system/core/DB.php';
		if(strstr(getcwd(), 'system\lib'))
			$dbPath = '../core/DB.php';
		require_once($dbPath);
		SJB_DB :: init(SJB_System::getSystemSettings('DBHOST'), SJB_System::getSystemSettings('DBUSER'), SJB_System::getSystemSettings('DBPASSWORD'), SJB_System::getSystemSettings('DBNAME'));
		$user_sid = 0;
		if(isset($_SESSION['current_user']))
			$user_sid = $_SESSION['current_user']['sid'];
			
		if (count(SJB_DB::query("select * from session where `session_id` = ?s", $id)) > 0)
			SJB_DB::query("update session set `data` = ?s, `time` = ?s, `user_sid` = ?n where `session_id` = ?s", $session_data, time(), $user_sid, $id);
		else
			SJB_DB::query("insert into session (`session_id`, `data`, `time`, `user_sid`) values (?s, ?s, ?s, ?n)", $id, $session_data, time(), $user_sid);
		return true;
	}
}